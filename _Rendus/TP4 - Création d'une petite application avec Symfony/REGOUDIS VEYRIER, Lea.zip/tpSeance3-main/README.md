Pour acceder a l'application :
- activer le server symfony
- aller a l'adresse : http://127.0.0.1:8000/homePage
Merci.
