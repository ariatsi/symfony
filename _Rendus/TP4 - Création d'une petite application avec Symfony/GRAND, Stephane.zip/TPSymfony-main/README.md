# TPSymfony
TP Symfony
Suite des TP de mon Cours de Symfony à l'AFIP.
Information au 07/11/2023 après TP3:
Après avoir entrer le ligne de commande $ symfony serve
Accéder à https://localhost:8000 pour vérifier que tout est fonctionnel.
Page de départ https://localhost:8000/pages.
CSS pas effectué...
