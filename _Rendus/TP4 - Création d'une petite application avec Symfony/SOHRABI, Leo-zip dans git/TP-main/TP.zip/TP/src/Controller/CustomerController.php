<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CustomerController extends AbstractController
{

    public function listCustomers(): Response
    {
        $customers = [
            ['name' => 'Client 1'],
            ['name' => 'Client 2'],
        ];

        return $this->render('customers/list.html.twig', [
            'customers' => $customers,
        ]);
    }


    public function showCustomer($id): Response
    {
        $customer = ['name' => 'Client ' . $id]; 

        return $this->render('customers/detail.html.twig', [
            'customer' => $customer,
        ]);
    }
}

