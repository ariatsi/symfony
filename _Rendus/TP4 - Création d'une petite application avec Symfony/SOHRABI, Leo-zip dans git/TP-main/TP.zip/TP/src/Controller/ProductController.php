<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{
    /**
     * @Route("/products", name="product_list")
     */
    public function listProducts(): Response
    {
        $products = [
            // ...
        ];

        return $this->render('products.html.twig', [
            'products' => $products,
        ]);
    }

    /**
     * @Route("/product/{id}", name="product_detail")
     */
    public function showProduct(Request $request, $id): Response
    {
        $product = $this->getProductById($id);

        if (!$product) {
            throw $this->createNotFoundException('Le produit avec l\'ID '.$id.' n\'existe pas.');
        }

        return $this->render('products.html.twig', [
            'product' => $product,
        ]);
    }

    private function getProductById(int $id): ?array
    {
        $products = [
            1 => ['name' => 'Produit 1', 'price' => 100],
            2 => ['name' => 'Produit 2', 'price' => 150],
        ];

        return $products[$id] ?? null;
    }
}
