<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/customer' => [[['_route' => 'app_customer', '_controller' => 'App\\Controller\\CustomerController::index'], null, null, null, false, false, null]],
        '/showCustomers' => [[['_route' => 'show_customer', '_controller' => 'App\\Controller\\CustomerController::showCustomer'], null, null, null, false, false, null]],
        '/home/contoller' => [[['_route' => 'app_home_contoller', '_controller' => 'App\\Controller\\HomeContollerController::index'], null, null, null, false, false, null]],
        '/homePage' => [[['_route' => 'home_page', '_controller' => 'App\\Controller\\HomeContollerController::home'], null, null, null, false, false, null]],
        '/product' => [[['_route' => 'app_product', '_controller' => 'App\\Controller\\ProductController::index'], null, null, null, false, false, null]],
        '/showProducts' => [[['_route' => 'show_product', '_controller' => 'App\\Controller\\ProductController::showProduct'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/more/([^/]++)(*:56)'
                .'|/info/([^/]++)(*:77)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        56 => [[['_route' => 'more_info', '_controller' => 'App\\Controller\\HomeContollerController::getInfo'], ['id'], null, null, false, true, null]],
        77 => [
            [['_route' => 'client_info', '_controller' => 'App\\Controller\\HomeContollerController::getMore'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
