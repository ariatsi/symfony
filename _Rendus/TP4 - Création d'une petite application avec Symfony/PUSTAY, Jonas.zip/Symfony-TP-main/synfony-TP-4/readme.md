Dasboard page : https://127.0.0.1:8000/index
Show product list : https://127.0.0.1:8000/showProducts
Show client list : https://127.0.0.1:8000/showCustomers
Show product detail :  https://127.0.0.1:8000/category/(entre 0 et 2)